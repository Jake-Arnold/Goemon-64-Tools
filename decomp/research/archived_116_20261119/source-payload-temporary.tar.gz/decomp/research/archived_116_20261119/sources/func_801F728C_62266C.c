typedef signed int s32;typedef unsigned int u32;typedef unsigned char u8;typedef signed char s8;typedef signed short s16;typedef unsigned short u16;typedef float f32;typedef double f64;typedef signed int M2C_UNK;
#define NULL ((void*)0)
#define M2C_FIELD(p,t,o) (*(t)((u8*)(p)+(o)))
#define M2C_PTR(p,t,o) ((t)((u8*)(p)+(o)))
M2C_UNK func_801F7214_6225F4(s32);                  /* static */

void func_801F728C_62266C(void *arg0, M2C_UNK arg1) {
    func_801F7214_6225F4(M2C_FIELD(arg0, s32 *, 0x90));
}
