typedef signed int s32;typedef unsigned int u32;typedef unsigned char u8;typedef signed char s8;typedef signed short s16;typedef unsigned short u16;typedef float f32;typedef double f64;typedef signed int M2C_UNK;
#define NULL ((void*)0)
#define M2C_FIELD(p,t,o) (*(t)((u8*)(p)+(o)))
#define M2C_PTR(p,t,o) ((t)((u8*)(p)+(o)))
M2C_UNK func_80034EF8_35AF8(void *);                /* extern */
M2C_UNK func_8021671C_6756CC(s32);                  /* static */

void func_80214C90_673C40(void *arg0) {
    func_8021671C_6756CC(M2C_FIELD(arg0, s32 *, 0x94));
    func_80034EF8_35AF8(arg0);
}
