#include "common.h"
#include "tools/m2c/m2c_macros.h"
extern f32 sqrtf(f32);
#pragma intrinsic(sqrtf)

f32 func_80003E10_4A10(u16);                        /* extern */
f32 func_80003EA0_4AA0(u16);                   /* extern */
u16 func_800040A8_4CA8(f32, f32);                   /* extern */
s32 func_8001D394_1DF94(f32 *);                     /* extern */
void func_8001D718_1E318(); /* extern */
void func_8001D898_1E498(); /* extern */
u16 func_801CE3F0_58A300(void *, f32); /* static */
u16 func_801CEAD4_58A9E4(void *, void *);     /* static */
s32 func_801E7DE8_5A3CF8(void *);          /* static */
extern f32 D_800C7DBC;
extern void *D_8020CA2C_5C893C;
extern void *D_801FC604_5B8514;
extern void *D_801FC60C_5B851C;
extern f32 D_8020A8A4_5C67B4;
extern f32 D_8020A8A8_5C67B8;
extern f64 D_8020A8B0_5C67C0;
extern f32 D_8020A8B8_5C67C8;
extern f64 D_8020A8C0_5C67D0;
extern f32 D_8020A8C8_5C67D8;
extern f32 D_8020A8CC_5C67DC;
extern f64 D_8020A8D0_5C67E0;
extern f64 D_8020A8D8_5C67E8;
extern f64 D_8020A8E0_5C67F0;
extern f32 D_8020A8E8_5C67F8;
extern f64 D_8020A8F0_5C6800;
extern f64 D_8020A8F8_5C6808;
extern f64 D_8020A900_5C6810;
extern f64 D_8020A908_5C6818;
extern f64 D_8020A910_5C6820;
extern f64 D_8020A918_5C6828;
extern f64 D_8020A920_5C6830;
extern f64 D_8020A928_5C6838;
extern f64 D_8020A930_5C6840;
extern f32 D_8020A938_5C6848;
extern f64 D_8020A940_5C6850;
extern f64 D_8020A948_5C6858;
extern f64 D_8020A950_5C6860;
extern f32 D_8020A958_5C6868;
extern f64 D_8020A960_5C6870;
extern f64 D_8020A968_5C6878;

u16 func_801CD310_589220(u8 *arg0, f32 arg1, f32 arg2) {
    u16 pool_u16_0;
    u16 pool_u16_1;
    u16 pool_u16_2;
    u16 pool_u16_3;
    u16 pool_u16_4;
    f32 pool_fp_1;
    f32 pool_fp_2;
    u8 magnitude_valid;
    f32 pool_fp_3;
    f32 pool_fp_4;
    f32 pool_fp_5;
    f32 pool_fp_6;
    f32 pool_fp_7;
    f32 pool_fp_8;
    f32 pool_fp_9;
    f32 pool_fp_10;
    f32 * pool_pf_0;
    f32 * pool_pf_1;
    f32 * pool_pf_2;
    f32 * pool_pf_3;
    s32 pool_s32_0;
    s32 pool_s32_1;
    u8 pool_u8_0;
    f32 vecA[3];
    f32 vecB[3];
    f32 vecD[3];
    union { struct { f32 trig_result; f32 gap; u16 switch_angles[2]; } t; f32 vecC[3]; } angles_and_vecC;

    f32 pool_fp_0;
    void *temp_v0_7;
    void *temp_v1;
    void *temp_v1_3;
    void *temp_v1_5;
    void *temp_v1_6;
    void *temp_v1_7;
    void *temp_v1_8;
    void *var_v1;
    void *var_v1_2;
    void *var_v1_3;

    M2C_FIELD(arg0, f32 *, 0x74) = 0.0f;
    M2C_FIELD(arg0, f32 *, 0x78) = 0.0f;
    M2C_FIELD(arg0, f32 *, 0x7C) = 0.0f;
    M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), s16 *, 8) = 0x400;
    if (M2C_FIELD(arg0, u8 *, 0x61) != 0) {
        return func_801CEAD4_58A9E4(arg0, arg0 + 0x68);
    }
    if (M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u8 *, 0x18) & 1) {
        arg2 = M2C_FIELD(D_8020CA2C_5C893C, f32 *, 0xC);
        arg1 = 4.0f;
    }
    pool_u16_0 = func_801CE3F0_58A300(arg0, arg2);
    switch (M2C_FIELD(arg0, u16 *, 0x98)) {
    case 0x95:
    case 0x9A:
        angles_and_vecC.t.switch_angles[1] = 0x100;
        angles_and_vecC.t.switch_angles[0] = 0x50;
        pool_fp_0 = (f32) (f64) D_8020A8A4_5C67B4;
        break;
    case 0x99:
        angles_and_vecC.t.switch_angles[1] = 0x60;
        angles_and_vecC.t.switch_angles[0] = 0x50;
        pool_fp_0 = (f32) ((f64) D_8020A8A8_5C67B8 * D_8020A8B0_5C67C0);
        break;
    case 0x94:
        angles_and_vecC.t.switch_angles[1] = 0x90;
        angles_and_vecC.t.switch_angles[0] = 0x50;
        pool_fp_0 = (f32) ((f64) D_8020A8B8_5C67C8 * D_8020A8C0_5C67D0);
        break;
    case 0x8E:
        angles_and_vecC.t.switch_angles[1] = 0x40;
        angles_and_vecC.t.switch_angles[0] = 0x30;
        pool_fp_0 = (f32) ((f64) D_8020A8C8_5C67D8 * 0.5);
        break;
    case 0x9F:
    default:
        angles_and_vecC.t.switch_angles[1] = 0x70;
        angles_and_vecC.t.switch_angles[0] = 0x50;
        pool_fp_0 = (f32) (f64) D_8020A8CC_5C67DC;
        break;
    }

    func_80003EA0_4AA0(angles_and_vecC.t.switch_angles[1]);
    angles_and_vecC.t.trig_result = func_80003EA0_4AA0(angles_and_vecC.t.switch_angles[0]);
    temp_v1 = M2C_FIELD(arg0, void **, 0x5C);
    pool_u8_0 = M2C_FIELD(temp_v1, u8 *, 0x59);
    if ((pool_u8_0 != 0) && (!(pool_u8_0 & 0x80) || ((M2C_FIELD(D_801FC60C_5B851C, f32 *, 0x20) * 40.0f) < M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), f32 *, 0x54)))) {
        M2C_FIELD(arg0, f32 *, 0x7C) = 0.0f;
        M2C_FIELD(arg0, f32 *, 0x74) = 0.0f;
        M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
        M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
        temp_v1 = M2C_FIELD(arg0, void **, 0x5C);
        pool_u8_0 = M2C_FIELD(temp_v1, u8 *, 0x59);
    }
    magnitude_valid = 0;
    pool_u16_2 = 0;
    if (((pool_u8_0 == 0) && (M2C_FIELD(arg0, u16 *, 0x98) != 0) && (M2C_FIELD(arg0, f32 *, 0xA4) <= 0.0f)) || (M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u16 *, 0) & 2)) {
        if ((f64) M2C_FIELD(arg0, f32 *, 0x88) < D_8020A8D0_5C67E0) {
            M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
            var_v1 = M2C_FIELD(arg0, void **, 0x5C);
            pool_pf_0 = arg0 + 0x84;
        } else {
            vecB[0] = M2C_FIELD(arg0, f32 *, 0x68);
            vecB[1] = M2C_FIELD(arg0, f32 *, 0x6C);
            vecB[2] = M2C_FIELD(arg0, f32 *, 0x70);
            func_8001D394_1DF94(&vecB[0]);
            pool_pf_1 = arg0 + 0x84;
            pool_pf_0 = pool_pf_1;
            func_8001D898_1E498(&vecB[0], &vecA[0], pool_pf_1);
            if (D_8020A8D8_5C67E8 < (f64) vecA[1]) {
                var_v1 = M2C_FIELD(arg0, void **, 0x5C);
                M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
                M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
                M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
            } else {
                vecA[1] = 0.0f;
                func_8001D394_1DF94(&vecA[0]);
                func_8001D718_1E318(&vecA[0], arg0 + 0x68, pool_pf_0);
                var_v1 = M2C_FIELD(arg0, void **, 0x5C);
                M2C_FIELD(arg0, f32 *, 0x68) = (f32) (M2C_FIELD(arg0, f32 *, 0x68) * M2C_FIELD(var_v1, f32 *, 0xB0));
                M2C_FIELD(arg0, f32 *, 0x6C) = (f32) (M2C_FIELD(arg0, f32 *, 0x6C) * M2C_FIELD(var_v1, f32 *, 0xB0));
                M2C_FIELD(arg0, f32 *, 0x70) = (f32) (M2C_FIELD(arg0, f32 *, 0x70) * M2C_FIELD(var_v1, f32 *, 0xB0));
            }
        }
        if ((M2C_FIELD(var_v1, u8 *, 0xAA) == 0) && (pool_u16_3 = M2C_FIELD(arg0, u16 *, 0x98), (pool_u16_3 != 0x9A)) && (pool_u16_3 != 0x95) && (pool_u16_3 != 0x81)) {
            pool_fp_3 = M2C_FIELD(arg0, f32 *, 0x88);
            if (pool_fp_3 < 0.0f) {
                pool_fp_4 = -pool_fp_3;
            } else {
                pool_fp_4 = pool_fp_3;
            }
            if (angles_and_vecC.t.trig_result < pool_fp_4) {
                goto block_33;
            }
            M2C_FIELD(var_v1, u8 *, 0x18) = (u8) (M2C_FIELD(var_v1, u8 *, 0x18) & 0xFFFD);
        } else {
block_33:
            M2C_FIELD(var_v1, u8 *, 0x18) = (u8) (M2C_FIELD(var_v1, u8 *, 0x18) | 2);
        }
        temp_v1 = M2C_FIELD(arg0, void **, 0x5C);
        pool_u8_0 = M2C_FIELD(temp_v1, u8 *, 0x18);
        if (!(pool_u8_0 & 1)) {
            if ((pool_u8_0 == 0) && (D_8020A8E0_5C67F0 < (f64) M2C_FIELD(temp_v1, f32 *, 0xB0)) && ((M2C_FIELD(temp_v1, u16 *, 0xA) & 0x1F) != 0x1F)) {
                func_8001D898_1E498(arg0 + 0x68, &vecA[0], pool_pf_0);
                vecA[1] = 0.0f;
                if (func_8001D394_1DF94(&vecA[0]) != 0) {
                    func_8001D718_1E318(&vecA[0], &vecB[0], pool_pf_0);
                    if (vecB[1] < -func_80003E10_4A10(angles_and_vecC.t.switch_angles[1])) {
                        temp_v1_3 = M2C_FIELD(arg0, void **, 0x5C);
                        M2C_FIELD(temp_v1_3, u8 *, 0x18) = (u8) (M2C_FIELD(temp_v1_3, u8 *, 0x18) | 1);
                    }
                }
            }
        } else {
            pool_fp_1 = M2C_FIELD(arg0, f32 *, 0x74);
            pool_fp_3 = M2C_FIELD(arg0, f32 *, 0x78);
            pool_fp_4 = M2C_FIELD(arg0, f32 *, 0x7C);
            pool_u16_2 = pool_u16_0;
            pool_fp_2 = sqrtf((pool_fp_4 * pool_fp_4) + ((pool_fp_1 * pool_fp_1) + (pool_fp_3 * pool_fp_3)));
            magnitude_valid = 1;
            M2C_FIELD(arg0, f32 *, 0x74) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x78) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x7C) = 0.0f;
        }
        vecB[2] = 0.0f;
        pool_fp_1 = M2C_FIELD(arg0, f32 *, 0x78);
        vecB[1] = D_8020A8E8_5C67F8;
        vecB[0] = vecB[2];
        func_8001D898_1E498(&vecB[0], &vecA[0], pool_pf_0);
        pool_fp_3 = vecA[1];
        vecA[1] = 0.0f;
        pool_fp_4 = pool_fp_3;
        pool_fp_5 = sqrtf((vecA[2] * vecA[2]) + (vecA[0] * vecA[0]));
        pool_fp_6 = pool_fp_5;
        pool_fp_5 = (f32) ((f64) pool_fp_3 / D_8020A8F0_5C6800);
        func_8001D718_1E318(&vecA[0], &vecB[0], pool_pf_0);
        pool_fp_3 = pool_fp_5;
        if (pool_fp_6 < 0.0f) {
            pool_fp_5 = -pool_fp_6;
        } else {
            pool_fp_5 = pool_fp_6;
        }
        if ((f64) pool_fp_5 < D_8020A8F8_5C6808) {
            pool_fp_5 = 0.0f;
        } else {
            pool_fp_5 = ((pool_fp_0 * pool_fp_4) + pool_fp_6) / pool_fp_6;
            if (pool_fp_5 < 0.0f) {
                pool_fp_5 = 0.0f;
            }
        }
        pool_u16_1 = M2C_FIELD(arg0, u16 *, 0x98);
        if ((pool_u16_1 == 0x9A) || (pool_u16_1 == 0x95)) {
            pool_fp_3 = 1.0f;
            pool_fp_5 = 0.0f;
        }
        pool_fp_6 = M2C_FIELD(arg0, f32 *, 0x68);
        pool_fp_7 = M2C_FIELD(arg0, f32 *, 0x6C);
        pool_fp_8 = M2C_FIELD(arg0, f32 *, 0x70);
        M2C_FIELD(arg0, f32 *, 0x74) = (f32) ((vecB[0] * pool_fp_5) + (M2C_FIELD(arg0, f32 *, 0x74) * pool_fp_3));
        M2C_FIELD(arg0, f32 *, 0x78) = (f32) ((vecB[1] * pool_fp_5) + (M2C_FIELD(arg0, f32 *, 0x78) * pool_fp_3));
        M2C_FIELD(arg0, f32 *, 0x7C) = (f32) ((vecB[2] * pool_fp_5) + (M2C_FIELD(arg0, f32 *, 0x7C) * pool_fp_3));
        pool_fp_3 = sqrtf((pool_fp_8 * pool_fp_8) + ((pool_fp_6 * pool_fp_6) + (pool_fp_7 * pool_fp_7)));
        pool_fp_5 = pool_fp_3;
        temp_v1_3 = M2C_FIELD(arg0, void **, 0x5C);
        pool_u8_0 = M2C_FIELD(temp_v1_3, u8 *, 0x18);
        if (!(pool_u8_0 & 1) || (pool_u8_0 & 2)) {
            if ((f64) pool_fp_3 <= D_8020A900_5C6810) {
                M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
                M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
                M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
                pool_u8_0 = M2C_FIELD(temp_v1_3, u8 *, 0x18);
                if (pool_u8_0 & 1) {
                    M2C_FIELD(temp_v1_3, u8 *, 0x18) = (u8) (pool_u8_0 | 8);
                }
                pool_fp_6 = M2C_FIELD(arg0, f32 *, 0x68);
                pool_fp_7 = M2C_FIELD(arg0, f32 *, 0x6C);
            } else {
                func_8001D898_1E498(arg0 + 0x74, &vecA[0], pool_pf_0);
                pool_fp_3 = (f32) ((f64) (vecA[1] + pool_fp_4) / D_8020A908_5C6818);
                temp_v1_5 = M2C_FIELD(arg0, void **, 0x5C);
                if (M2C_FIELD(temp_v1_5, u8 *, 0x18) & 2) {
                    pool_fp_4 = 1.0f;
                } else {
                    if (M2C_FIELD(temp_v1_5, u16 *, 0) & 2) {
                        pool_fp_9 = M2C_FIELD(temp_v1_5, f32 *, 4);
                    } else {
                        pool_fp_9 = D_800C7DBC;
                    }
                    pool_fp_4 = (f32) (1.0 - ((f64) pool_fp_9 / D_8020A910_5C6820));
                    if (D_8020A918_5C6828 < (f64) sqrtf((vecA[2] * vecA[2]) + (vecA[0] * vecA[0]))) {
                        pool_fp_9 = pool_fp_4;
                        func_8001D898_1E498(arg0 + 0x68, &angles_and_vecC.vecC[0], pool_pf_0);
                        pool_u16_1 = func_800040A8_4CA8(angles_and_vecC.vecC[0], angles_and_vecC.vecC[2]);
                        pool_fp_4 = pool_fp_9;
                        if ((((pool_u16_1 - func_800040A8_4CA8(vecA[0], vecA[2])) + 0x40) & 0x3FF) >= 0x81) {
                            pool_fp_4 = 1.0f;
                            M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
                            M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
                            M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
                        }
                    }
                }
                if ((f64) pool_fp_4 < 0.0) {
                    pool_fp_4 = 0.0f;
                }
                pool_u16_3 = M2C_FIELD(arg0, u16 *, 0x98);
                pool_fp_10 = (pool_fp_5 - (pool_fp_4 * pool_fp_0 * pool_fp_3)) / pool_fp_5;
                pool_fp_3 = pool_fp_10;
                if ((((pool_u16_3 == 0x9A) || (pool_u16_3 == 0x95)) && (((f64) D_800C7DBC < D_8020A920_5C6830) || ((temp_v0_7 = M2C_FIELD(D_801FC604_5B8514, void **, 0x5C), ((M2C_FIELD(temp_v0_7, u16 *, 0) & 2) != 0)) && ((f64) M2C_FIELD(temp_v0_7, f32 *, 4) < D_8020A920_5C6830)))) || (pool_fp_10 < 0.0f)) {
                    pool_fp_3 = 0.0f;
                }
                if (pool_fp_3 > 1.0f) {
                    pool_fp_3 = 1.0f;
                }
                M2C_FIELD(arg0, f32 *, 0x68) = (f32) (M2C_FIELD(arg0, f32 *, 0x68) * pool_fp_3);
                pool_fp_6 = M2C_FIELD(arg0, f32 *, 0x68);
                M2C_FIELD(arg0, f32 *, 0x6C) = (f32) (M2C_FIELD(arg0, f32 *, 0x6C) * pool_fp_3);
                pool_fp_7 = M2C_FIELD(arg0, f32 *, 0x6C);
                M2C_FIELD(arg0, f32 *, 0x70) = (f32) (M2C_FIELD(arg0, f32 *, 0x70) * pool_fp_3);
            }
            pool_fp_8 = M2C_FIELD(arg0, f32 *, 0x70);
        }
        M2C_FIELD(arg0, f32 *, 0x68) = (f32) (pool_fp_6 + M2C_FIELD(arg0, f32 *, 0x74));
        pool_fp_3 = M2C_FIELD(arg0, f32 *, 0x68);
        M2C_FIELD(arg0, f32 *, 0x70) = (f32) (pool_fp_8 + M2C_FIELD(arg0, f32 *, 0x7C));
        pool_fp_4 = M2C_FIELD(arg0, f32 *, 0x70);
        M2C_FIELD(arg0, f32 *, 0x6C) = (f32) (pool_fp_7 + M2C_FIELD(arg0, f32 *, 0x78));
        pool_fp_6 = M2C_FIELD(arg0, f32 *, 0x6C);
        pool_fp_7 = sqrtf((pool_fp_4 * pool_fp_4) + ((pool_fp_3 * pool_fp_3) + (pool_fp_6 * pool_fp_6)));
        pool_fp_5 = pool_fp_7;
        if (arg1 < pool_fp_7) {
            pool_fp_5 = arg1 / pool_fp_7;
            M2C_FIELD(arg0, f32 *, 0x68) = (f32) (pool_fp_3 * pool_fp_5);
            M2C_FIELD(arg0, f32 *, 0x70) = (f32) (pool_fp_4 * pool_fp_5);
            M2C_FIELD(arg0, f32 *, 0x6C) = (f32) (pool_fp_6 * pool_fp_5);
        }
        var_v1_2 = M2C_FIELD(arg0, void **, 0x5C);
        if (M2C_FIELD(var_v1_2, u8 *, 0x18) == 0) {
            pool_s32_0 = M2C_FIELD(var_v1_2, u16 *, 0xA) & 0x1F;
            pool_s32_1 = pool_s32_0;
            if (pool_s32_0 == 0x1F) {
                if (func_801E7DE8_5A3CF8(arg0) != 0) {
                    var_v1_2 = M2C_FIELD(arg0, void **, 0x5C);
                    pool_s32_1 = M2C_FIELD(var_v1_2, u16 *, 0xA) & 0x1F;
                    goto block_87;
                }
            } else {
block_87:
                if ((pool_s32_1 != 0x1F) && (pool_fp_1 >= 0.0f) && (M2C_FIELD(arg0, f32 *, 0x6C) < 0.0f) && ((f64) M2C_FIELD(arg0, f32 *, 0x78) < D_8020A928_5C6838)) {
                    M2C_FIELD(var_v1_2, u8 *, 0x18) = (u8) (M2C_FIELD(var_v1_2, u8 *, 0x18) | 1);
                }
            }
        }
        temp_v1_6 = M2C_FIELD(arg0, void **, 0x5C);
        pool_u8_0 = M2C_FIELD(temp_v1_6, u8 *, 0x18);
        if ((pool_u8_0 & 1) && (pool_u8_0 & 2) && !(pool_u8_0 & 8) && ((f64) pool_fp_5 < 0.5)) {
            M2C_FIELD(temp_v1_6, u8 *, 0x18) = (u8) (pool_u8_0 | 4);
        } else {
            M2C_FIELD(temp_v1_6, u8 *, 0x18) = (u8) (pool_u8_0 & 0xFFFB);
        }
        if (M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u8 *, 0x18) & 8) {
            M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
            pool_u16_0 = 0x400;
        }
    } else {
        M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u8 *, 0x18) = (u8) (M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u8 *, 0x18) & 0xFFFD);
        if (M2C_FIELD(arg0, f32 *, 0x78) < 0.0f) {
            pool_fp_1 = M2C_FIELD(arg0, f32 *, 0x84);
            vecD[0] = pool_fp_1;
            pool_fp_3 = M2C_FIELD(arg0, f32 *, 0x88);
            vecD[1] = pool_fp_3;
            pool_fp_4 = M2C_FIELD(arg0, f32 *, 0x8C);
            vecD[2] = pool_fp_4;
            M2C_FIELD(arg0, f32 *, 0x84) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x8C) = 0.0f;
            M2C_FIELD(arg0, f32 *, 0x88) = 1.0f;
            pool_u16_0 = func_801CE3F0_58A300(arg0, arg2);
            M2C_FIELD(arg0, f32 *, 0x84) = pool_fp_1;
            M2C_FIELD(arg0, f32 *, 0x88) = pool_fp_3;
            M2C_FIELD(arg0, f32 *, 0x8C) = vecD[2];
        }
        temp_v1_7 = M2C_FIELD(arg0, void **, 0x5C);
        pool_fp_1 = M2C_FIELD(temp_v1_7, f32 *, 0xB0);
        if (pool_fp_1 < 0.0f) {
            pool_fp_3 = -pool_fp_1;
        } else {
            pool_fp_3 = pool_fp_1;
        }
        if (!((f64) pool_fp_3 < D_8020A930_5C6840) && !(M2C_FIELD(temp_v1_7, u8 *, 0x18) & 1)) {
            pool_pf_1 = arg0 + 0x84;
            if (pool_fp_1 <= D_8020A938_5C6848) {
                M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
                M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
            } else {
                pool_pf_0 = pool_pf_1;
                func_8001D898_1E498(arg0 + 0x74, &vecA[0], pool_pf_1);
                temp_v1_8 = M2C_FIELD(arg0, void **, 0x5C);
                if (M2C_FIELD(temp_v1_8, u16 *, 0) & 2) {
                    pool_fp_1 = M2C_FIELD(temp_v1_8, f32 *, 4);
                } else {
                    pool_fp_1 = D_800C7DBC;
                }
                pool_fp_3 = (f32) (1.0 - ((f64) pool_fp_1 / D_8020A940_5C6850));
                if (D_8020A948_5C6858 < (f64) sqrtf((vecA[2] * vecA[2]) + (vecA[0] * vecA[0]))) {
                    pool_fp_9 = pool_fp_3;
                    func_8001D898_1E498(arg0 + 0x68, &angles_and_vecC.vecC[0], pool_pf_0);
                    pool_u16_1 = func_800040A8_4CA8(angles_and_vecC.vecC[0], angles_and_vecC.vecC[2]);
                    pool_fp_3 = pool_fp_9;
                    if ((((pool_u16_1 - func_800040A8_4CA8(vecA[0], vecA[2])) + 0x40) & 0x3FF) >= 0x81) {
                        pool_fp_3 = 1.0f;
                        M2C_FIELD(arg0, f32 *, 0x70) = 0.0f;
                        M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
                        M2C_FIELD(arg0, f32 *, 0x68) = 0.0f;
                    }
                }
                if ((f64) pool_fp_3 < 0.0) {
                    pool_fp_3 = 0.0f;
                }
                pool_fp_1 = M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), f32 *, 0xB0);
                pool_fp_4 = (pool_fp_1 - (pool_fp_3 * pool_fp_0)) / pool_fp_1;
                if (pool_fp_4 < 0.0f) {
                    pool_fp_4 = 0.0f;
                }
                M2C_FIELD(arg0, f32 *, 0x68) = (f32) (M2C_FIELD(arg0, f32 *, 0x68) * pool_fp_4);
                M2C_FIELD(arg0, f32 *, 0x70) = (f32) (M2C_FIELD(arg0, f32 *, 0x70) * pool_fp_4);
            }
        }
        M2C_FIELD(arg0, f32 *, 0x68) = (f32) (M2C_FIELD(arg0, f32 *, 0x68) + M2C_FIELD(arg0, f32 *, 0x74));
        pool_fp_0 = M2C_FIELD(arg0, f32 *, 0x68);
        M2C_FIELD(arg0, f32 *, 0x70) = (f32) (M2C_FIELD(arg0, f32 *, 0x70) + M2C_FIELD(arg0, f32 *, 0x7C));
        pool_fp_1 = M2C_FIELD(arg0, f32 *, 0x70);
        pool_fp_3 = sqrtf((pool_fp_1 * pool_fp_1) + (pool_fp_0 * pool_fp_0));
        pool_fp_5 = pool_fp_3;
        if (arg1 < pool_fp_3) {
            pool_fp_5 = arg1 / pool_fp_3;
            M2C_FIELD(arg0, f32 *, 0x68) = (f32) (pool_fp_0 * pool_fp_5);
            M2C_FIELD(arg0, f32 *, 0x70) = (f32) (pool_fp_1 * pool_fp_5);
        }
    }
    var_v1_3 = M2C_FIELD(arg0, void **, 0x5C);
    M2C_FIELD(arg0, f32 *, 0x6C) = 0.0f;
    pool_pf_1 = arg0 + 0xA8;
    pool_pf_2 = arg0 + 0x84;
    if (M2C_FIELD(var_v1_3, u8 *, 0x19) & 2) {
        pool_pf_3 = pool_pf_1;
        pool_pf_0 = pool_pf_2;
        func_8001D898_1E498(pool_pf_1, &vecA[0], pool_pf_2);
        pool_fp_0 = sqrtf((vecA[2] * vecA[2]) + (vecA[0] * vecA[0]));
        if (pool_fp_0 < 0.0f) {
            pool_fp_1 = -pool_fp_0;
        } else {
            pool_fp_1 = pool_fp_0;
        }
        if ((f64) pool_fp_1 < D_8020A950_5C6860) {
            vecA[0] = 0.0f;
            vecA[2] = 0.0f;
            vecA[1] = D_8020A958_5C6868;
            func_8001D718_1E318(&vecA[0], &vecB[0], pool_pf_3);
        } else {
            vecA[1] = 0.0f;
            pool_fp_1 = (f32) (D_8020A960_5C6870 / (f64) pool_fp_0);
            vecA[0] *= pool_fp_1;
            vecA[2] *= pool_fp_1;
            func_8001D718_1E318(&vecA[0], &vecB[0], pool_pf_0);
        }
        var_v1_3 = M2C_FIELD(arg0, void **, 0x5C);
        M2C_FIELD(arg0, f32 *, 0x68) = (f32) (M2C_FIELD(arg0, f32 *, 0x68) + vecB[0]);
        M2C_FIELD(arg0, f32 *, 0x6C) = (f32) (M2C_FIELD(arg0, f32 *, 0x6C) + vecB[1]);
        M2C_FIELD(arg0, f32 *, 0x70) = (f32) (M2C_FIELD(arg0, f32 *, 0x70) + vecB[2]);
    }
    M2C_FIELD(var_v1_3, s8 *, 0x19) = 0;
    if (M2C_FIELD(M2C_FIELD(arg0, void **, 0x5C), u8 *, 0x18) & 1) {
        pool_pf_1 = arg0 + 0x68;
        pool_pf_2 = arg0 + 0x84;
        pool_u16_0 = M2C_FIELD(arg0, u16 *, 0x94);
        if (D_8020A968_5C6878 <= (f64) pool_fp_5) {
            pool_pf_3 = pool_pf_1;
            pool_pf_0 = pool_pf_2;
            func_8001D898_1E498(pool_pf_1, &angles_and_vecC.vecC[0], pool_pf_2);
            pool_fp_0 = sqrtf((angles_and_vecC.vecC[2] * angles_and_vecC.vecC[2]) + (angles_and_vecC.vecC[0] * angles_and_vecC.vecC[0]));
            pool_u16_1 = func_800040A8_4CA8(angles_and_vecC.vecC[0], angles_and_vecC.vecC[2]);
            pool_u16_3 = pool_u16_1;
            pool_u16_4 = pool_u16_2 - pool_u16_1;
            pool_u16_2 = pool_u16_4;
            if (!magnitude_valid) {
                pool_fp_2 = 0.0f;
            }
            pool_fp_2 *= func_80003E10_4A10(pool_u16_4 & 0xFFFF);
            pool_u16_1 = pool_u16_3 + (s32) (32.0f * pool_fp_2);
            pool_u16_3 = pool_u16_1;
            pool_fp_1 = func_80003E10_4A10(pool_u16_1 & 0xFFFF) * pool_fp_0;
            angles_and_vecC.vecC[0] = pool_fp_1;
            angles_and_vecC.vecC[2] = func_80003EA0_4AA0(pool_u16_3) * pool_fp_0;
            func_8001D718_1E318(&angles_and_vecC.vecC[0], pool_pf_3, pool_pf_0);
            pool_u16_1 = pool_u16_3;
        } else {
            pool_u16_1 = pool_u16_0;
        }
        pool_s32_0 = (pool_u16_0 - pool_u16_1) & 0x3FF;
        if (((pool_s32_0 + 8) & 0x1FF) < 0x10) {
            if ((pool_s32_0 + 0x100) & 0x200) {
                pool_u16_0 = (pool_u16_1 + 0x200) & 0x3FF;
            } else {
                pool_u16_0 = pool_u16_1;
            }
        } else if (pool_s32_0 & 0x100) {
            pool_u16_0 = (pool_u16_0 + 8) & 0x3FF;
        } else {
            pool_u16_0 = (pool_u16_0 - 8) & 0x3FF;
        }
    }
    return pool_u16_0;
}
