typedef unsigned char u8;typedef unsigned int u32;typedef unsigned short u16;
extern u8 *D_8020EED0_63A2B0;
void func_801FFE54_62B234(void){*(u32*)(*(u8**)(D_8020EED0_63A2B0+472)+100)=90;}
